﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PilotInfoDBA.Model
{
    internal class DatabaseManager
    {
        private OracleConnection con;
        private OracleCommand cmd = new OracleCommand();
        public StreamReader sr = new StreamReader("datei.txt");
        List<string> daten = new List<string>();
        public DatabaseManager() 
        {
            string password = sr.ReadLine();
            string connectionString = "Data Source=dbserver2.bg.bib.de:1521/ora10.bg.bib.de;User ID=bbm3h22mme;Password=" + password;
            con = new OracleConnection(connectionString);
            con.Open();
            Console.WriteLine("Verbindung erfolgreich hergestellt!");
            con.Close();
        }

        public List<string> Show(string id)
        {
            con.Open();
            string sql = "SELECT id FROM A_Mitglied";
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sql;
            OracleDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                if (string.IsNullOrEmpty(id))
                {
                    throw new Exception("Invalid ID!");
                }
                else
                {
                    break;
                }
            }

            string nachname = "";
            string titel = "Kein Titel";
            string geburts = "";
            string eintritt = "";
            string ort = "";
            int mitgliedID = Convert.ToInt32(id);
            sql = "SELECT nachname, titel, geburtsdatum, eintrittsdatum, ort FROM A_Mitglied WHERE id=" + mitgliedID;
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sql;
            //cmd.Transaction = con.BeginTransaction();
            //cmd.Transaction.Commit();
            reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                daten.Add(reader["nachname"].ToString());
                daten.Add((reader["titel"] != DBNull.Value ? reader["titel"].ToString() : "NO"));
                daten.Add(reader["geburtsdatum"].ToString());
                daten.Add(reader["eintrittsdatum"].ToString());
                daten.Add(reader["ort"].ToString());
            }

            con.Close();
            return daten; //gibt liste zurück
        }
        public int Safe(string id, string nachname, string titel, string gebjahr, string eintritt, string ort)
        {
            con.Open();
            int Iid = Convert.ToInt32(id);
            string sql = "UPDATE A_Mitglied SET id ="+Iid+", nachname = '"+nachname+"', titel = '"+titel+ "', geburtsdatum = CAST('" + gebjahr+"' AS DATE), eintrittsdatum = CAST('"+eintritt+"' AS DATE), ort = '"+ort+"' WHERE id = "+Iid;
            cmd.Connection = con;
            cmd.CommandType= System.Data.CommandType.Text;
            cmd.CommandText = sql;
            cmd.Transaction = con.BeginTransaction();
            int ergebnis = cmd.ExecuteNonQuery();
            cmd.Transaction.Commit();
            con.Close();
            return ergebnis;
        }

        public int NewMember(string id, string nachname, string vorname, string titel, string gebjahr, string eintritt, string ort, string geschlecht, string plz)
        {
            con.Open();
            string checkId = "SELECT id FROM A_Mitglied";
            cmd.Connection= con;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = checkId;
            OracleDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                if (id.Equals(reader["id"].ToString()))
                {
                    throw new Exception("Id exists already! Choose another!");
                }
            }
            //checks if there are letters instead of numbers in the strig
            bool containsNoLetter = !gebjahr.Any(x => char.IsLetter(x));
            DateTime geburtsjahr = DateTime.Now;
            if (!string.IsNullOrEmpty(gebjahr) || containsNoLetter)
            {
                string[] gebjahrUmwandeln = gebjahr.Split('.');
                int day = Convert.ToInt32(gebjahrUmwandeln[0]);
                int month = Convert.ToInt32(gebjahrUmwandeln[1]);
                int year = Convert.ToInt32(gebjahrUmwandeln[2]);
                geburtsjahr = new DateTime(year, month, day);
                if (geburtsjahr.AddYears(17) >= DateTime.Now)
                {
                    throw new Exception("You are to young!");
                }
            }
            else
            {
                throw new Exception("Invalid input!");
            }
            if(eintritt.Any(x => char.IsLetter(x)) || string.IsNullOrEmpty(eintritt))
            {
                throw new Exception("Invalid Eintrittsdatum!");
            } else if (eintritt.Contains("-"))
            {
                string[] datum = eintritt.Split('-');
                string year = datum[0];
                string month = datum[1];
                string day = datum[2];
                eintritt = day+"."+month+"."+year;
            }
            char g;
            if (geschlecht.Length > 1)
            {
                g = geschlecht[0];
            }
            else
            {
                g = Convert.ToChar(geschlecht);
            }
            if(plz.Length >= 6 || plz.Any(x => char.IsLetter(x)))
            {
                throw new Exception("Invalid PLZ");
            }
            string sql = "INSERT INTO A_Mitglied (ID, NACHNAME, VORNAME, TITEL, GEBURTSDATUM, EINTRITTSDATUM, ORT, GESCHLECHT, PLZ) " +
             "VALUES (" + id + ", '" + nachname + "', '" + vorname + "', '" + titel + "', TO_DATE('" + gebjahr + "', 'DD.MM.YYYY'), " +
             "TO_DATE('" + eintritt + "', 'DD.MM.YYYY'), '" + ort + "', '" + g + "', '" + plz + "')";
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sql;
            cmd.Transaction = con.BeginTransaction();
            int ergebnis = cmd.ExecuteNonQuery();
            cmd.Transaction.Commit();
            con.Close();
            return ergebnis;
        }
        public string IDExample()
        {
            con.Open();
            string sql = "SELECT id FROM A_Mitglied";
            int id = 1;
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sql;
            OracleDataReader r = cmd.ExecuteReader();
            while (r.Read())
            {
                if(r["id"].ToString() == id.ToString())
                {
                    id++;
                }
            }
            con.Close();
            return id.ToString();
        }
    }
}
