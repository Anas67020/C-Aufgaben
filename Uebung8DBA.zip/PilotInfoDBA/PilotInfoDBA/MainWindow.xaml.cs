﻿using PilotInfoDBA.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PilotInfoDBA
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DatabaseManager db = new DatabaseManager();
        List<string> output = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SAVE(object sender, RoutedEventArgs e)
        {
            try
            {
                int ausgabe = db.Safe(tID.Text, tNachname.Text, tTitel.Text, tGeburtsjahr.Text, tEintritt.Text, tOrt.Text);
                if (ausgabe == 1)
                {
                    Statuszeile.Text = "Es wurde/n " + ausgabe + " Datensätze geändert.";
                }
            }
            catch (Exception ex)
            {
                Statuszeile.Text = ex.Message;
            }
        }
        private void NEWMEMBER(object sender, RoutedEventArgs e)
        {
            NewMemberWindow nM = new NewMemberWindow();
            nM.Show();
            Close();
        }
        private void QUIT(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Enter_Taste(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                try
                {
                    output = db.Show(tID.Text);
                    string[] help = output[2].Split(' ');
                    string[] help2 = output[3].Split(' ');
                    tNachname.Text = output[0];
                    tTitel.Text = output[1];
                    tGeburtsjahr.Text = help[0];
                    tEintritt.Text = help2[0];
                    tOrt.Text = output[4];
                }
                catch (Exception ex)
                {
                    Statuszeile.Text = ex.Message;
                }
            }
        }
    }
}
