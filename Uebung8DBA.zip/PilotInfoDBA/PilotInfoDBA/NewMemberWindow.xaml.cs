﻿using PilotInfoDBA.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PilotInfoDBA
{
    /// <summary>
    /// Interaktionslogik für NewMemberWindow.xaml
    /// </summary>
    public partial class NewMemberWindow : Window
    {
        DatabaseManager db = new DatabaseManager();
        public NewMemberWindow()
        {
            InitializeComponent();
            MtID.Text = db.IDExample();
            MtEintritt.Text = DateTime.Now.ToShortDateString().ToString();
        }
        private void SAVE(object sender, RoutedEventArgs e)
        {
            try
            {
                int returnInt = db.NewMember(MtID.Text, MtNachname.Text,MtVorname.Text, MtTitel.Text, MtGeburtsjahr.Text, MtEintritt.Text, MtOrt.Text, MtGeschlecht.Text, MtPLZ.Text);
                if (returnInt == 1)
                {
                    MStatuszeile.Text = "Es wurde/n " + returnInt + " Datensätze eingefuegt.";
                }
            }
            catch (Exception ex)
            {
                MStatuszeile.Text = ex.Message;
            }
        }
        private void QUIT(object sender, RoutedEventArgs e)
        { 
            MainWindow mW = new MainWindow();
            mW.Show();
            Close();
        }
        private void Enter_Taste(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                try
                {
                    SAVE(sender, e);
                }
                catch (Exception ex)
                {
                    MStatuszeile.Text = ex.Message;
                }
            }
        }
    }
}
