﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DataGrid
{
    internal class DBM
    {
        public OracleCommand cmd;
        public OracleConnection con;
        public StreamReader sr = new StreamReader("datei.txt");
        public DBM()
        {
            string password = sr.ReadLine();
            string connectionString = "Data Source=dbserver2.bg.bib.de:1521/ora10.bg.bib.de;User ID=bbm3h22mme;Password=" + password;
            con = new OracleConnection(connectionString);
            con.Open();
            Console.WriteLine("Verbindung erfolgreich hergestellt!");
            con.Close();
        }
        public DataTable Suche()
        {
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;

            cmd.CommandText = "SELECT vorname, nachname, titel, GEBURTSDATUM FROM A_MITGLIED;";
            cmd.Connection.Open();

            OracleDataReader datareader = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(datareader);
            datareader.Close();
            return dt;
        }
    }
}
