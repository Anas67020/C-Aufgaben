﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatenbankDaten.Model
{
    internal class db
    {
        private string password = new StreamReader(new FileStream("datei.txt", FileMode.Open)).ReadLine();
        OracleConnection con;
        private OracleCommand cmd;

        public db()
        {
            try
            {
                string conString = "Data Source=dbserver2.bg.bib.de:1521/ora10.bg.bib.de;User ID=bbm3h22mme;Password=" + password;
                con = new OracleConnection(conString);
                /*con.Open();
                string s = "ServerVersion: " + con.ServerVersion + "\nDataSource: " + con.DataSource;
                Console.WriteLine("Connection erfolgreich");
                Console.WriteLine(s);
                con.Close();*/
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public void Insert()
        {
            try {
                //string sql = "insert into dbtest (attr1, attr2, attr3, attr4, attr5) values (101, 'Hallo', 'A', 2.5, '05,11,2024')";
                int var1 = 102;
                string var2 = "Guten TAg";
                char var3 = 'X';
                float x = 1.7f;
                string var4 = Convert.ToString(x);
                DateTime var5 = new DateTime(2024, 12,24);

                string sql = "insert into dbtest (attr1, attr2, attr3, attr4, attr5) values (" + var1 +
                                                                                            ", '"+ var2+ "', '"+ 
                                                                                            var3+"', '"+
                                                                                            var4+"',TO_DATE('"+
                                                                                            var5.ToShortDateString()+ "','dd.mm.yyyy'))";
                cmd = new OracleCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.Connection.Open();
                cmd.Transaction = con.BeginTransaction();
                cmd.CommandText = sql;
                int ergebnis = cmd.ExecuteNonQuery();
                if (ergebnis > 0) { Console.WriteLine("Datensatz wurde gespeichert."); cmd.Transaction.Commit(); }
                cmd.Connection.Close();
            } catch (SqlException e) {
                Console.WriteLine(e.Message);
            }
        }
    }
}
