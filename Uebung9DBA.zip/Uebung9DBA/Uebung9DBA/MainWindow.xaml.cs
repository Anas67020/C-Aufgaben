﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Uebung9DBA.Model;

namespace Uebung9DBA
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DatabaseManager dm = new DatabaseManager();
        public MainWindow()
        {
            InitializeComponent();
            dg.ItemsSource = dm.DataGrid().DefaultView;
            tbMID.ItemsSource = dm.ExistingIDs();
            tbMID.SelectedIndex = 0;
        }

        private void bBeenden_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void bSpeichern_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Statuszeile.Text = "Es wurden " +dm.SafeData(tbMID.Text, dpD.Text, tbBiE.Text) + " Datensätze gespeichert.";
            }
            catch (Exception ex)
            {
                Statuszeile.Text = ex.Message;
            }
        }

        private void Enter(object sender, KeyEventArgs e)
       {
            if (e.Key == Key.Enter)
            {
                try
                {
                    if (string.IsNullOrEmpty(tbMID.Text))
                    {
                        dg.ItemsSource = dm.DataGrid().DefaultView;
                        tbN.Text = "";
                        tbGesamt.Text = "";
                    }
                    else
                    {
                        string output = dm.DatenAnzeigen(tbMID.Text);
                        string[] splitString = output.Split(';');
                        tbN.Text = splitString[0];
                        tbGesamt.Text = splitString[1];
                        dg.ItemsSource = dm.AnzeigenNachID(tbMID.Text, tbN.Text).DefaultView;
                    }
                }
                catch (Exception ex)
                {
                    Statuszeile.Text = ex.Message;
                }
            }
        }
    }
}
