﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Management.Instrumentation;
using System.Text;
using System.Threading.Tasks;

namespace Uebung9DBA.Model
{
    internal class DatabaseManager
    {
        private OracleCommand cmd;
        private OracleConnection con;
        public StreamReader sr = new StreamReader("datei.txt");

        public DatabaseManager() 
        {
            string password = sr.ReadLine();
            string conString = "Data Source=dbserver2.bg.bib.de:1521/ora10.bg.bib.de;User ID=bbm3h22mme;Password="+password;
            con = new OracleConnection(conString);
            Console.WriteLine("Verbindung erfolgreich hergestellt!");
        }
        public DataTable DataGrid()
        {
            con.Open();
            cmd = new OracleCommand();
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "SELECT id, nachname, eintrittsdatum, A_Praemie.betrag" +
                " FROM A_Mitglied JOIN A_Praemie ON A_Mitglied.id = A_Praemie.Mitgliedid ORDER BY id, eintrittsdatum ";
            OracleDataReader reader = cmd.ExecuteReader();
            DataTable data = new DataTable();
            data.Load(reader);
            reader.Close();
            con.Close();
            return data;
        }
        public DataTable AnzeigenNachID(string id,string nachname)
        {
            con.Open();
            cmd = new OracleCommand();
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = "SELECT id, nachname, eintrittsdatum, A_Praemie.betrag FROM A_Mitglied JOIN A_Praemie ON A_Mitglied.id = A_Praemie.Mitgliedid WHERE a_mitglied.nachname='"+nachname+"' AND a_praemie.mitgliedid = "+id+" ORDER BY id, eintrittsdatum";
            OracleDataReader reader = cmd.ExecuteReader();
            DataTable data = new DataTable();
            data.Load(reader);
            reader.Close();
            con.Close();
            return data;
        }
        public string DatenAnzeigen(string MitgliedID)
        {
            con.Open();
            OracleDataReader reader;
            if (MitgliedID.Any(x => char.IsLetter(x))) throw new Exception("MitgliedID enthält Zeichen die nicht erlaubt sind!");
            else
            {
                int id = Convert.ToInt32(MitgliedID);
                string checkId = "SELECT Mitgliedid FROM A_Praemie WHERE Mitgliedid=" + id;
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = checkId;
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string getData = "SELECT nachname, SUM(A_Praemie.BETRAG) AS gesamtbetrag FROM A_Mitglied JOIN A_Praemie ON A_MITGLIED.id = A_PRAEMIE.Mitgliedid WHERE A_Praemie.Mitgliedid = " + id + "GROUP BY A_Mitglied.nachname";
                    cmd.Connection = con;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = getData;
                    reader = cmd.ExecuteReader();
                    string nachname = "";
                    string gesamtbetrag = "";
                    while (reader.Read())
                    {
                        nachname = reader["nachname"].ToString();
                        gesamtbetrag = reader["gesamtbetrag"].ToString();
                    }
                    con.Close();
                    return nachname + ";" + gesamtbetrag;
                }
                else throw new Exception("Id doesn't exist!");
            }
        }
        public string[] ExistingIDs()
        {
            string[] id = new string[100];
            id[0] = "";
            con.Open();
            string sql = "SELECT id FROM A_MITGLIED";
            cmd.Connection = con;
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sql;
            OracleDataReader r = cmd.ExecuteReader();
            for (int i = 1; r.Read(); i++)
            {
                id[i] = r["id"].ToString();
            }
            con.Close();
            return id;
        }
        public int SafeData(string id,string date,string betrag)
        {
            if (string.IsNullOrEmpty(id))
            {
                throw new Exception("Bitte wählen Sie eine ID aus!");
            }
            else
            {
                if (betrag.Any(x => char.IsLetter(x))) throw new Exception("Betrag enthält Zeichen die nicht erlaubt sind!");
                else
                {
                    con.Open();
                    string sql = "INSERT INTO A_PRAEMIE (MITGLIEDID, DATUM, BETRAG) VALUES ("+id+", TO_DATE('"+date+"', 'DD.MM.YYYY'),"+betrag+")";
                    cmd.Connection = con;
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = sql;
                    cmd.Transaction = con.BeginTransaction();
                    int erg = cmd.ExecuteNonQuery();
                    cmd.Transaction.Commit();
                    con.Close();
                    return erg;
                }
            }
        }
    }
}
