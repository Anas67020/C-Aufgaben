﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Uebung7DBA
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Aufgabe 1
            //Console.WriteLine("Bitte geben Sie das Alter ein mit dem Sie dem Verein beigetreten sind: ");
            //string altereingabe = Console.ReadLine();
            //int alter = Convert.ToInt32(altereingabe);
            DatenbankConnection db = new DatenbankConnection();
            //db.AlterBeigetreten(alter);
            //Aufgabe2
            Console.WriteLine("Bitte geben Sie den Ort der Spieler ein: ");
            string ort = Console.ReadLine();
            Console.WriteLine("Bitte geben Sie ein jahr ein: ");
            int year = Convert.ToInt32(Console.ReadLine());
            db.KeinePraemie(ort, year);
        }
        
    }
}
