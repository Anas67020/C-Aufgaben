﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Uebung7DBA
{
    internal class DatenbankConnection
    {
        private OracleConnection connection;
        private OracleCommand command;
        public StreamReader sr = new StreamReader("datei.txt");
        //command.Transaction = connection.BeginTransaction();
        //SELECT DATUM FROM A_PRAEMIE Where BETRAG = (SELECT MAX(BETRAG) FROM A_PRAEMIE);

        public DatenbankConnection()
        {
            string password = sr.ReadLine();
            string connectionString = "Data Source=dbserver2.bg.bib.de:1521/ora10.bg.bib.de;User ID=bbm3h22mme;Password="+password;
            connection = new OracleConnection(connectionString);
            connection.Open();
            Console.WriteLine("Verbindung erfolgreich hergestellt!");
        }

        public void AlterBeigetreten(int alter)
        {
            command = new OracleCommand();
            command.Connection = connection;
            command.CommandType = System.Data.CommandType.Text;
            command.CommandText = "select nachname, vorname, round((eintrittsdatum - geburtsdatum)/365)" + "from A_MITGLIED where round((eintrittsdatum - geburtsdatum)/365) = "+ alter;
            
            OracleDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine(reader["nachname"].ToString() + "\n" +
                                    reader["vorname"].ToString());
            }
            reader.Close();
            command.Connection.Close();
        }

        public void KeinePraemie(string ort, int datum)
        {
            command = new OracleCommand();
            command.Connection = connection;
            command.CommandType = System.Data.CommandType.Text;
            command.CommandText = "SELECT vorname, nachname FROM A_MITGLIED WHERE ID NOT IN (SELECT MITGLIEDID FROM A_PRAEMIE WHERE EXTRACT(YEAR FROM datum) = "+ datum + ") AND ort = '" + ort + "' ";
            //connection.Open();
            OracleDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine(reader["vorname"].ToString() + " " + reader["nachname"]);
            }
            reader.Close();
            command.Connection.Close();
        }

    }
}
